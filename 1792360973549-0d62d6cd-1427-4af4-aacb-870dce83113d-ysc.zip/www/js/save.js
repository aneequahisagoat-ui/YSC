/* YSC local save: coins, gems, YSC tokens, squad, progression. Offline, on the device. */
const Save = {
  data:null,
  defaults(){
    return {
      clubName:"", badge:null,
      coins:25000, gems:50, chips:10, tokens:10,
      xp:0, squad:[], picks:0, campaign:0,
      managers:[], teamCustom:false,
      kit:{ shirt:"#c8102e", shorts:"#0b0b10", num:"#ffcf3f" },
      dailyDate:null, dailyDone:[]
    };
  },
  load(){
    if(this.data) return this.data;
    try { this.data = Object.assign(this.defaults(), JSON.parse(localStorage.getItem("ysc_save")||"{}")); }
    catch(e){ this.data = this.defaults(); }
    return this.data;
  },
  save(){ localStorage.setItem("ysc_save", JSON.stringify(this.data)); }
};
