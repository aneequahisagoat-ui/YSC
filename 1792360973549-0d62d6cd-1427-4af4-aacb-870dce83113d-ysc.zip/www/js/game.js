/* YSC match engine - 11v11 with AI, tackling, fouls, set pieces, offside and a diving keeper.
   Ball + player physics in metres on a 105x68 pitch. Rendering is delegated:
   Three.js 3D when available (render3d.js), otherwise a 2D canvas fallback.
   Every player carries an anim state { run, kick, dive, tackle, cele, stun } that the
   renderer turns into motion; the sim itself stays simple and readable. */
const FIELD = { w:105, h:68, goalH:7.32*1.4 };

function fmtAnim(){ return { kick:0, dive:0, tackle:0, cele:0, stun:0 }; }

class Match {
  constructor(stage, opts){
    this.el = stage;
    this.diff = opts.difficulty || "medium";
    this.homeName = opts.homeName || "YSC";
    this.awayName = opts.awayName || "Rivals";
    this.homeKit = opts.homeKit; this.awayKit = opts.awayKit;
    this.homeSquad = opts.homeSquad || [];
    this.awaySquad = opts.awaySquad || [];
    this.onEnd = opts.onEnd || function(){};
    this.onGoal = opts.onGoal || function(){};
    this.onSay = opts.onSay || function(){};
    this.controls = { mx:0, my:0, shoot:false, pass:false, tackle:false };
    this.speed = { easy:0.82, medium:1.0, hard:1.18 }[this.diff] || 1.0;
    this.sayCd = 0;
    this.reset();
    this.buildRenderer();
  }
  fmt(role,x,y){ return { role, x, y, vx:0, vy:0, anim:fmtAnim(), _tackleCd:0, diveDir:1 }; }
  formation(side){ // side 0 = home (attacking +x), 1 = away
    const rows = [ ["GK"], ["RB","CB","CB","LB"], ["CM","CM","CM"], ["RW","ST","LW"] ];
    const xs = side===0 ? [6,22,40,70] : [99,83,65,35];
    const out=[];
    rows.forEach((row,ri)=>{
      row.forEach((pos,i)=>{
        const y = (FIELD.h/(row.length+1))*(i+1);
        out.push(this.fmt(pos, xs[ri], y));
      });
    });
    return out;
  }
  /* glue squad names/looks onto the formation slots */
  lineout(side){
    const squad = side===0 ? this.homeSquad : this.awaySquad;
    const f = this.formation(side);
    return f.map((slot,i)=>{
      const pl = squad[i] || {};
      return Object.assign(slot, { team:side, name: pl.n || slot.role, rating: pl.r || 75, pos: pl.p || slot.role });
    });
  }
  reset(){
    this.home = this.lineout(0);
    this.away = this.lineout(1);
    this.ball = { x:FIELD.w/2, y:FIELD.h/2, vx:0, vy:0 };
    this.score={h:0,a:0}; this.clock=0; this.total=90; this.realPerGameMin=2.0; // 90 min in ~3 real min
    this.controlled = this.closest(this.home);
    this.running=false; this.last=0;
    this.state="play";           // play | setpiece | celebrate | over
    this.restart=null; this.celeT=0; this.lastScorerTeam=0;
  }
  buildRenderer(){
    this.r3d = null;
    try {
      if(window.Pitch3D) this.r3d = new Pitch3D(this.el, this);
    } catch(e){ console.warn("3D failed, falling back to 2D:", e && e.message); this.r3d = null; }
    if(!this.r3d){
      this.canvas = document.createElement("canvas");
      this.canvas.className = "pitch2d";
      this.el.appendChild(this.canvas);
      this.ctx = this.canvas.getContext("2d");
      this.resize();
    }
  }
  closest(list){
    let best=null,bd=1e9;
    list.forEach(p=>{ const d=Math.hypot(p.x-this.ball.x,p.y-this.ball.y); if(d<bd){bd=d;best=p;} });
    return best;
  }
  owner(list){ const b=this.closest(list); return (b && Math.hypot(b.x-this.ball.x,b.y-this.ball.y)<1.6) ? b : null; }
  homeOwner(){ return this.owner(this.home); }
  awayOwner(){ return this.owner(this.away); }
  say(key, force){
    if(this.sayCd>0 && !force) return;
    this.sayCd = force?0.8:1.6;
    this.onSay(key);
    if(window.GameAudio) GameAudio.say(key);
  }
  start(){ this.running=true; this.last=performance.now(); if(window.GameAudio) GameAudio.crowd(0.06); requestAnimationFrame(t=>this.loop(t)); }
  stop(){ this.running=false; if(window.GameAudio) GameAudio.crowd(0); }
  loop(t){
    if(!this.running) return;
    let dt=(t-this.last)/1000; this.last=t; dt=Math.min(dt,0.05);
    this.update(dt); this.draw();
    requestAnimationFrame(tt=>this.loop(tt));
  }
  update(dt){
    this.sayCd = Math.max(0, this.sayCd-dt);
    this.decayAnims(dt);

    if(this.state==="celebrate"){
      this.celeT -= dt;
      if(this.celeT<=0) this.kickoff(this.lastScorerTeam===0?1:0);
      this.controlled = this.closest(this.home);
      this.clock += dt*(this.total/this.realPerGameMin/60);
      return;
    }
    if(this.state==="setpiece"){
      this.updateSetPiece(dt);
      this.clock += dt*(this.total/this.realPerGameMin/60);
      if(this.clock>=this.total) this.finish();
      return;
    }
    if(this.state==="over") return;

    const spd = 7.0*this.speed;
    const all = this.home.concat(this.away);
    const cp = this.controlled;

    // ---- control input
    if(cp && cp.anim.stun<=0){
      cp.vx += this.controls.mx*spd*6*dt;
      cp.vy += this.controls.my*spd*6*dt;
      if(this.controls.shoot) this.tryKick(cp, 40);
      else if(this.controls.pass) this.tryPass(cp);
      else if(this.controls.tackle) this.tryTackle(cp);
    }

    // ---- AI off-ball + away team
    all.forEach(p=>{
      if(p.anim.stun>0) return;
      const team = p.team===0 ? this.home : this.away;
      const dir = p.team===0 ? 1 : -1;              // attacking direction
      const targetGoal = { x: dir>0?FIELD.w:0, y: FIELD.h/2 };
      const owner = p.team===0 ? this.homeOwner() : this.awayOwner();
      const oppOwner = p.team===0 ? this.awayOwner() : this.homeOwner();
      let tx,ty;
      const near = this.closest(team);
      const chase = (near && near.role!=="GK") ? near : null;
      if(p.role==="GK"){
        tx = p.team===0?3:FIELD.w-3;
        ty = FIELD.h/2 + (this.ball.y-FIELD.h/2)*0.5;
        ty = Math.max(FIELD.h/2-FIELD.goalH/2-1, Math.min(FIELD.h/2+FIELD.goalH/2+1, ty));
      }
      else if(p===cp){ tx=p.x; ty=p.y; } // player-controlled: no AI steering
      else if(owner===p){ tx = targetGoal.x; ty = targetGoal.y + (this.ball.y-FIELD.h/2)*0.3; }
      else if(chase===p){ tx=this.ball.x; ty=this.ball.y; }
      else {
        const ballPull = (this.ball.x-FIELD.w/2)*0.15;
        tx = p.x + ballPull*dir*0.5; ty = p.y + (this.ball.y-p.y)*0.15;
        tx = Math.max(2, Math.min(FIELD.w-2, tx));
        ty = Math.max(2, Math.min(FIELD.h-2, ty));
      }
      let dx=tx-p.x, dy=ty-p.y, d=Math.hypot(dx,dy)||1;
      const s = (p.role==="GK"?spd*0.7:spd*0.85);
      p.vx += (dx/d)*s*3*dt; p.vy += (dy/d)*s*3*dt;

      // defender challenges the man on the ball
      if(oppOwner && p.role!=="GK" && !p._tackleCd && Math.hypot(p.x-oppOwner.x,p.y-oppOwner.y)<2.0){
        if(Math.random()<0.9*this.speed*dt*60/60) this.tryTackle(p);
      }
      // AI shot / pass when it owns ball
      if(owner===p){
        const gd = Math.hypot(targetGoal.x-p.x, targetGoal.y-p.y);
        if(gd < 34 && Math.random()<0.30*this.speed) this.tryKick(p, 40*(dir>0?1:-1));
        else if(Math.random()<0.03*this.speed) this.tryKick(p, 55*(dir>0?1:-1));
        else if(Math.random()<0.05) this.tryPass(p);
      }
    });

    // ---- integrate + friction
    all.forEach(p=>{
      p.x+=p.vx*dt; p.y+=p.vy*dt;
      p.vx*=0.86; p.vy*=0.86;
      p.x=Math.max(0.5,Math.min(FIELD.w-0.5,p.x));
      p.y=Math.max(0.5,Math.min(FIELD.h-0.5,p.y));
      if(p._tackleCd) p._tackleCd = Math.max(0, p._tackleCd-dt);
    });
    const b=this.ball;
    b.x+=b.vx*dt; b.y+=b.vy*dt; b.vx*=0.95; b.vy*=0.95;
    if(Math.abs(b.vx)<0.05)b.vx=0; if(Math.abs(b.vy)<0.05)b.vy=0;
    // walls
    if(b.y<1){b.y=1;b.vy=Math.abs(b.vy)*0.6;} if(b.y>FIELD.h-1){b.y=FIELD.h-1;b.vy=-Math.abs(b.vy)*0.6;}

    // ---- keeper reads the shot
    this.gkCheck(dt);

    // ---- goal detection (ball crosses the line inside the posts)
    const inBand = Math.abs(b.y-FIELD.h/2) < FIELD.goalH/2;
    if(b.x<=1 && inBand){ this.scoreGoal(1); return; }
    if(b.x>=FIELD.w-1 && inBand){ this.scoreGoal(0); return; }
    if(b.x<1){b.x=1;b.vx=Math.abs(b.vx)*0.5;}
    if(b.x>FIELD.w-1){b.x=FIELD.w-1;b.vx=-Math.abs(b.vx)*0.5;}

    // ball possession nudge + nearest controlled switch
    all.forEach(p=>{
      const d=Math.hypot(p.x-b.x,p.y-b.y);
      if(d<1.25){ b.vx = p.vx*1.25 + (p.x-b.x)*1.5; b.vy = p.vy*1.25 + (p.y-b.y)*1.5; }
    });
    this.controlled = this.closest(this.home);

    // "he's through" colour
    const ow = this.homeOwner() || this.awayOwner();
    if(ow && Math.hypot((ow.team===0?FIELD.w:0)-ow.x, FIELD.h/2-ow.y) < 24 && this.sayCd<=0 && Math.random()<0.25) this.say("through");

    // clock
    this.clock += dt*(this.total/this.realPerGameMin/60);
    if(this.clock>=this.total) this.finish();
  }
  decayAnims(dt){
    this.home.concat(this.away).forEach(p=>{
      const a=p.anim;
      a.kick=Math.max(0,a.kick-dt); a.dive=Math.max(0,a.dive-dt);
      a.tackle=Math.max(0,a.tackle-dt); a.cele=Math.max(0,a.cele-dt); a.stun=Math.max(0,a.stun-dt);
    });
  }
  /* keeper dives when a fast ball is heading into his goal; may save or concede */
  gkCheck(dt){
    const b=this.ball;
    const speed=Math.hypot(b.vx,b.vy);
    if(speed<7) return;
    const towardRight = b.x>FIELD.w/2 && b.vx>0;
    const towardLeft  = b.x<FIELD.w/2 && b.vx<0;
    if(!towardRight && !towardLeft) return;
    const gk = (towardRight?this.away:this.home).find(p=>p.role==="GK");
    if(!gk || gk.anim.dive>0) return;
    const gx = towardRight?FIELD.w:0;
    const dist = Math.abs(gx-b.x);
    const lat = Math.abs(b.y-FIELD.h/2);
    if(dist>19 || lat>FIELD.goalH/2+3) return;
    gk.diveDir = Math.sign(b.y-gk.y)||1;
    gk.anim.dive = 0.9;
    const odds = Math.max(0.15, Math.min(0.60, 0.24 + (gk.rating-74)/120 + (speed<14?0.05:0)));
    if(Math.random()<odds){
      const away = towardRight?-1:1;
      b.vx = away*(6+Math.random()*6);
      b.vy = (Math.random()-0.5)*10;
      b.x = gx + (towardRight?-1.5:1.5);
      this.say("save1", true);
      if(window.GameAudio){ GameAudio.crowd(0.45); GameAudio.thump(); }
      this.onSave && this.onSave();
    }
  }
  tryKick(p, power){
    const d=Math.hypot(p.x-this.ball.x,p.y-this.ball.y);
    if(d>2.2) return;
    const dir = p.team===0?1:-1;
    const gx = dir>0?FIELD.w:0;
    const ang = Math.atan2((FIELD.h/2 + (Math.random()-0.5)*4) - this.ball.y, gx - this.ball.x);
    this.ball.vx = Math.cos(ang)*Math.abs(power); this.ball.vy = Math.sin(ang)*Math.abs(power);
    p.anim.kick = 0.36;
    if(window.GameAudio) GameAudio.thump();
  }
  tryPass(p){
    const d=Math.hypot(p.x-this.ball.x,p.y-this.ball.y);
    if(d>2.4) return;
    const mates=(p.team===0?this.home:this.away).filter(m=>m!==p);
    let best=null,bd=1e9;
    const dir=p.team===0?1:-1;
    mates.forEach(m=>{ if((m.x-p.x)*dir<0) return; const dist=Math.hypot(m.x-p.x,m.y-p.y); if(dist<bd){bd=dist;best=m;} });
    if(!best) return;
    if(this.isOffside(p,best)){
      this.say("offside", true);
      if(window.GameAudio) GameAudio.whistle();
      this.startSetPiece("freekick", 1-p.team, best.x, best.y, best);
      return;
    }
    const ang=Math.atan2(best.y-this.ball.y, best.x-this.ball.x);
    this.ball.vx=Math.cos(ang)*14; this.ball.vy=Math.sin(ang)*14;
    p.anim.kick = 0.28;
  }
  isOffside(passer, receiver){
    const dir = passer.team===0?1:-1;
    if((receiver.x-FIELD.w/2)*dir <= 0) return false;   // not in the opponent half
    if((receiver.x-this.ball.x)*dir <= 0) return false; // not ahead of the ball
    const xs = (passer.team===0?this.away:this.home).map(d=>d.x*dir).sort((a,b)=>b-a);
    const line = xs.length>1 ? xs[1] : xs[0];           // second-last defender
    return receiver.x*dir > line + 0.3;
  }
  tryTackle(p){
    if(p._tackleCd>0 || p.anim.stun>0) return;
    p._tackleCd = 0.9;
    p.anim.tackle = 0.45;
    const opps = p.team===0?this.away:this.home;
    const o = this.owner(opps);
    if(!o || Math.hypot(o.x-p.x,o.y-p.y) > 2.6) return;
    const win = 0.34 + ((p.rating||75)-(o.rating||75))/220 + (this.controlled===p?0.16:0);
    if(Math.random() < win){
      const dir = p.team===0?1:-1;
      this.ball.x = p.x + dir*1.1; this.ball.y = p.y + (this.ball.y-p.y)*0.3;
      this.ball.vx = dir*3; this.ball.vy = (Math.random()-0.5)*4;
      o.anim.stun = 0.35;
      this.say("tackle");
      if(window.GameAudio) GameAudio.thump();
    } else if(Math.random() < 0.55){
      this.commitFoul(p, o);
    }
  }
  commitFoul(fouler, victim){
    const awarded = victim.team;                 // free kick to the team that was fouled
    const inBox = fouler.team===0 ? victim.x < 16.5 : victim.x > FIELD.w-16.5;
    const pen = inBox && Math.abs(victim.y-FIELD.h/2) < 20.16;
    this.say(pen?"penalty":"foul", true);
    if(window.GameAudio) GameAudio.whistle();
    this.startSetPiece(pen?"penalty":"freekick", awarded, victim.x, victim.y, victim);
  }
  pickTaker(team){
    const list=(team===0?this.home:this.away).filter(p=>p.role!=="GK");
    return list.sort((a,b)=>(b.rating||0)-(a.rating||0))[0] || (team===0?this.home:this.away)[0];
  }
  startSetPiece(type, team, x, y, victim){
    this.state="setpiece";
    let bx=x, by=y;
    if(type==="penalty"){
      bx = team===0 ? FIELD.w-11 : 11;
      by = FIELD.h/2;
    }
    this.ball = { x:bx, y:by, vx:0, vy:0 };
    const opp = team===0?this.away:this.home;
    opp.forEach(p=>{ p.vx=p.vy=0; });
    this.taker = this.pickTaker(team);
    this.restart = { type, team, x:bx, y:by, t:0, dur: type==="penalty"?1.7:1.3 };
    // put everyone onside-ish, hold opponents 9.15m from the ball
    const all=this.home.concat(this.away);
    all.forEach(p=>{
      if(p===this.taker || p.role==="GK") return;
      const d=Math.hypot(p.x-bx,p.y-by);
      if(d<9.15){
        const nx = d>0.01?(p.x-bx)/d:1, ny=d>0.01?(p.y-by)/d:0;
        p.x = bx + nx*(9.15+1); p.y = by + ny*(9.15+1);
      }
    });
    if(this.r3d) { /* camera handled in render */ }
  }
  updateSetPiece(dt){
    const r=this.restart; if(!r){ this.state="play"; return; }
    r.t += dt;
    const b=this.ball, taker=this.taker;
    // taker walks up to the ball
    if(taker){
      const dx=b.x-taker.x, dy=b.y-taker.y, d=Math.hypot(dx,dy)||1;
      if(d>1.1){ taker.x += (dx/d)*Math.min(d,7*dt); taker.y += (dy/d)*Math.min(d,7*dt); taker.vx=taker.vy=0; }
    }
    if(r.t>=r.dur){
      const dir = r.team===0?1:-1;
      const gx = dir>0?FIELD.w:0;
      const spread = r.type==="penalty"?2.2:6;
      const ang = Math.atan2((FIELD.h/2 + (Math.random()-0.5)*spread) - b.y, gx - b.x);
      const pow = r.type==="penalty"?28:21;
      b.vx = Math.cos(ang)*pow; b.vy = Math.sin(ang)*pow;
      if(taker) taker.anim.kick = 0.4;
      if(window.GameAudio) GameAudio.thump();
      this.state="play";
      this.restart=null;
    }
  }
  kickoff(team){
    this.state="play"; this.restart=null;
    this.ball={x:FIELD.w/2,y:FIELD.h/2,vx:0,vy:0};
    this.home.forEach((p,i)=>{ const f=this.formation(0)[i]; p.x=f.x; p.y=f.y; p.vx=p.vy=0; p._tackleCd=0.4; });
    this.away.forEach((p,i)=>{ const f=this.formation(1)[i]; p.x=f.x; p.y=f.y; p.vx=p.vy=0; p._tackleCd=0.4; });
    const all=this.home.concat(this.away);
    all.forEach(p=>{ p.anim.cele=0; });
    this.say("kickoff");
  }
  scoreGoal(team){
    if(team===0) this.score.h++; else this.score.a++;
    this.say(team===0?"goal1":"goal2", true);
    if(window.GameAudio) GameAudio.crowd(0.6);
    this.onGoal(team);
    this.lastScorerTeam = team;
    const scorers = team===0?this.home:this.away;
    scorers.forEach(p=>{ if(p.role!=="GK") p.anim.cele=2.0; });
    this.state="celebrate"; this.celeT=2.2;
  }
  finish(){ this.state="over"; this.running=false; this.say("final", true); if(window.GameAudio) GameAudio.crowd(0.3); this.onEnd(this.score); }
  draw(){
    if(this.r3d){ this.r3d.render(this); return; }
    if(!this.ctx) return;
    const ctx=this.ctx, W=this.canvas.width, H=this.canvas.height;
    const s=Math.min(W/FIELD.w, H/FIELD.h);
    this.s=s; this.ox=(W-FIELD.w*s)/2; this.oy=(H-FIELD.h*s)/2;
    ctx.clearRect(0,0,W,H);
    ctx.fillStyle="#0f2a17"; ctx.fillRect(0,0,W,H);
    ctx.save(); ctx.translate(this.ox,this.oy); ctx.scale(s,s);
    ctx.strokeStyle="rgba(255,255,255,.25)"; ctx.lineWidth=0.25;
    ctx.strokeRect(0,0,FIELD.w,FIELD.h);
    ctx.beginPath(); ctx.moveTo(FIELD.w/2,0); ctx.lineTo(FIELD.w/2,FIELD.h); ctx.stroke();
    ctx.beginPath(); ctx.arc(FIELD.w/2,FIELD.h/2,9.15,0,7); ctx.stroke();
    [0,FIELD.w].forEach(x=>{ ctx.strokeRect(x<1?0:FIELD.w-16.5, FIELD.h/2-20.15, 16.5, 40.3); });
    ctx.fillStyle="#dfe7ee";
    ctx.fillRect(-0.6, FIELD.h/2-FIELD.goalH/2, 0.8, FIELD.goalH);
    ctx.fillRect(FIELD.w-0.2, FIELD.h/2-FIELD.goalH/2, 0.8, FIELD.goalH);
    const drawP=(p,kit)=>{
      ctx.beginPath(); ctx.arc(p.x,p.y,1.0,0,7);
      ctx.fillStyle=kit.shirt; ctx.fill();
      ctx.lineWidth=0.15; ctx.strokeStyle=kit.num; ctx.stroke();
      if(p===this.controlled){ ctx.beginPath(); ctx.arc(p.x,p.y,1.6,0,7); ctx.strokeStyle="#ffd54a"; ctx.lineWidth=0.25; ctx.stroke(); }
    };
    this.home.forEach(p=>drawP(p,this.homeKit));
    this.away.forEach(p=>drawP(p,this.awayKit));
    ctx.beginPath(); ctx.arc(this.ball.x,this.ball.y,0.5,0,7); ctx.fillStyle="#fff"; ctx.fill();
    ctx.restore();
  }
  resize(){
    if(this.r3d){ this.r3d.resize(); return; }
    if(!this.canvas) return;
    const r=this.el.getBoundingClientRect();
    this.canvas.width=Math.max(1,r.width); this.canvas.height=Math.max(1,r.height);
  }
}
