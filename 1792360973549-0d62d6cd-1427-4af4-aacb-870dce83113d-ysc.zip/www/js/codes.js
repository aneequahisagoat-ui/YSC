/* YSC CODES SYSTEM
   Read CODES.md for how codes work. Add new codes to the DEFAULT_CODES list below.
   Codes are single-use per install. Effect types: money | picks | player | tokens */
const DEFAULT_CODES = {
  "MONEY":   { type:"money",  amount:100000, label:"+100,000 Sx" },
  "RONALDO": { type:"player", player:{ n:"Cristiano Ronaldo", r:99, p:"ST", c:"Your Soccer Club", nat:"Portugal", prime:true }, label:"Prime Cristiano Ronaldo" },
  "GIFT":    { type:"picks",  amount:3, label:"3 free market picks" },
  "YSC600":  { type:"tokens", amount:600, label:"+600 YSC Tokens" }
};

const Codes = {
  all(){ return DEFAULT_CODES; },
  redeemed(){
    try { return JSON.parse(localStorage.getItem("ysc_redeemed")||"[]"); } catch(e){ return []; }
  },
  hasRedeemed(code){ return this.redeemed().includes(code.toUpperCase()); },
  /* returns {ok, label, def} or {ok:false, reason} */
  redeem(raw){
    const code = (raw||"").trim().toUpperCase();
    if(!code) return {ok:false, reason:"Enter a code."};
    const def = DEFAULT_CODES[code];
    if(!def) return {ok:false, reason:"Unknown code: "+code};
    if(this.hasRedeemed(code)) return {ok:false, reason:"Code already used."};
    const list = this.redeemed(); list.push(code);
    localStorage.setItem("ysc_redeemed", JSON.stringify(list));
    return {ok:true, code, def, label:def.label};
  }
};
