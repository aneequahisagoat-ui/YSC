/* YSC app shell: screens, club, market, campaign, daily, store, codes, settings, match wiring */
const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));

const App = {
  match:null, diff:"medium",
  init(){
    Save.load(); Settings.load();
    this.applySettings(); this.renderClub(); this.renderMarket(); this.renderManagers(); this.renderCampaign(); this.renderDaily(); this.renderStore();
    this.bindNav(); this.bindSettings(); this.bindCodes(); this.bindBadge(); this.bindDiff(); this.bindMatchUI(); this.bindStore(); this.bindPack();
    window.addEventListener("resize", ()=>this.match && this.match.resize());
    const wake=()=>{ if(window.GameAudio){ GameAudio.init(); GameAudio.setOptions(Settings.data); } document.removeEventListener("pointerdown",wake); };
    document.addEventListener("pointerdown",wake);
    // dev hook for screenshots: ?screen=store  ?pack=premium
    try{ const q=new URLSearchParams(location.search); if(q.get("screen")) this.show(q.get("screen")); const pk=q.get("pack"); if(pk){ this.show("store"); setTimeout(()=>this.openPack(pk),150); if(q.get("tap")) setTimeout(()=>{ const p=$("#packPack"); if(p) p.click(); },700); } }catch(e){}
  },
  show(id){
    $$(".screen").forEach(s=>s.classList.remove("active"));
    $("#screen-"+id).classList.add("active");
    if(this.match && id!=="match"){ this.match.stop(); }
    if(id!=="match"){ this.match=null; }
  },
  toast(msg){ const t=$("#toast"); t.textContent=msg; t.classList.add("show"); clearTimeout(this._tt); this._tt=setTimeout(()=>t.classList.remove("show"),2200); },
  coins(){
    const set=(id,v)=>{ const e=$(id); if(e) e.textContent=v; };
    const c=Save.data.coins||0;
    set("#coinCount", c.toLocaleString()); set("#coinCount2", c.toLocaleString()); set("#coinCount3", c.toLocaleString());
    set("#gemCount",(Save.data.gems||0).toLocaleString()); set("#gemCount3",(Save.data.gems||0).toLocaleString());
    // the green token in the top bar / store IS the YSC token
    set("#chipCount",(Save.data.tokens||0).toLocaleString());
    set("#tokenCount3",(Save.data.tokens||0).toLocaleString());
    set("#exTokens",(Save.data.tokens||0).toLocaleString());
    set("#pickCount",(Save.data.picks||0).toLocaleString());
    set("#exCoins", c.toLocaleString()); set("#exPicks",(Save.data.picks||0));
  },
  managerBonus(){
    return (Save.data.managers||[]).reduce((s,id)=>{ const m=MANAGERS.find(x=>x.id===id); return s + (m?m.bonus:0); }, 0);
  },
  myPool(){ return (Save.data.squad && Save.data.squad.length>=11) ? Save.data.squad : ICONS.concat(Save.data.squad||[]); },
  ovrOf(pool){
    const raw = (pool && pool.length) ? pool : this.myPool();
    const xi = buildEleven((raw && raw.length>=11) ? raw : ICONS.concat(raw||[]));
    if(!xi || !xi.length) return 0;
    const base = xi.reduce((s,p)=>s+(p.r||70),0)/xi.length;
    return Math.min(99, Math.round(base) + this.managerBonus());
  },
  renderHome(){
    const name = Save.data.clubName || "Username";
    const hn=$("#hName"); if(hn) hn.textContent = name.length>14?name.slice(0,14):name;
    const av=$("#hAvatar"); if(av) av.src = Save.data.badge || "assets/ysc-icon.jpg";
    let lvl=1, xp=Save.data.xp||0;
    while(xp >= 35*lvl && lvl<999){ xp -= 35*lvl; lvl++; }
    const need = 35*lvl;
    const lv=$("#hLevel"); if(lv) lv.textContent=String(lvl);
    const bar=$("#hXp"); if(bar) bar.style.width = Math.min(100,(xp/need)*100)+"%";
    const txt=$("#hXpTxt"); if(txt) txt.textContent = xp+"/"+need+"XP";
    const ovr = this.ovrOf(Save.data.squad);
    const o1=$("#clubOvr"); if(o1) o1.textContent=ovr||"--";
    const o2=$("#clubOvr2"); if(o2) o2.textContent=ovr?(ovr+" · best XI"):"--";
    const mb=$("#mgrBonus"); if(mb) mb.textContent="+"+this.managerBonus();
  },
  renderSquad(){
    const list=$("#squadList"); if(!list) return; list.innerHTML="";
    buildEleven(this.myPool()).forEach((p,i)=>{
      const card=document.createElement("div"); card.className="card";
      card.innerHTML='<div class="p"><b>'+(i+1)+'. '+p.n+'</b><small>'+(p.p||"")+' · '+(p.c||"Free agent")+'</small></div><span class="rating">'+(p.r||70)+'</span>';
      list.appendChild(card);
    });
  },
  renderClub(){
    const cn=$("#clubName"); if(cn) cn.value = Save.data.clubName || "Your Soccer Club";
    const b=$("#clubBadge");
    if(b) b.innerHTML = Save.data.badge ? '<img src="'+Save.data.badge+'" alt="badge"/>' : '<img src="assets/ysc-icon.jpg" alt="YSC"/>';
    this.renderKitEditor();
    this.renderHome(); this.renderSquad(); this.coins();
  },
  renderKitEditor(){
    const wrap=$("#kitEditor"); if(!wrap) return;
    const unlocked = !!Save.data.teamCustom;
    wrap.classList.toggle("locked", !unlocked);
    const msg=$("#kitLockMsg"); if(msg) msg.style.display = unlocked ? "none" : "";
    const k=Save.data.kit||{};
    ["kitShirt","kitShorts","kitNum"].forEach((id,i)=>{
      const el=$("#"+id); if(!el) return;
      el.disabled=!unlocked;
      el.value = [k.shirt,k.shorts,k.num][i] || "#c8102e";
      el.oninput = ()=>{
        if(!Save.data.teamCustom) return;
        Save.data.kit = { shirt:$("#kitShirt").value, shorts:$("#kitShorts").value, num:$("#kitNum").value };
        Save.save();
      };
    });
  },
  bindBadge(){
    $("#clubName").addEventListener("input", e=>{ Save.data.clubName=e.target.value; Save.save(); this.renderClub(); });
    $("#btnImportBadge").addEventListener("click", ()=>{
      const inp=document.createElement("input"); inp.type="file"; inp.accept="image/*";
      inp.onchange=()=>{ const f=inp.files[0]; if(!f) return; const fr=new FileReader();
        fr.onload=()=>{ Save.data.badge=fr.result; Save.save(); this.renderClub(); this.toast("Badge set from your phone."); };
        fr.readAsDataURL(f); };
      inp.click();
    });
  },
  bindNav(){ $$("[data-go]").forEach(b=>b.addEventListener("click",()=>{
    const g=b.dataset.go;
    if(g==="match") this.startMatch();
    else if(g==="friends") this.toast("Friends list lands after launch.");
    else this.show(g);
  })); },
  bindStore(){
    const news=$("#btnNews"); if(news) news.onclick=()=>this.toast("No news yet. Go win something.");
    const mail=$("#btnMail"); if(mail) mail.onclick=()=>this.toast("No mail. Inbox zero.");
    // exchange screen
    const bp=$("#exBuyPick");
    if(bp) bp.onclick=()=>{ if(Save.data.coins<50000){ this.toast("Need 50,000 Sx."); return; } Save.data.coins-=50000; Save.data.picks+=1; Save.save(); this.renderClub(); this.toast("1 pick ready."); };
    const sp=$("#exSellPick");
    if(sp) sp.onclick=()=>{ if((Save.data.picks||0)<1){ this.toast("No picks to sell."); return; } Save.data.picks-=1; Save.data.coins+=25000; Save.save(); this.renderClub(); this.toast("+25,000 Sx."); };
    const gt=$("#exGemTokens");
    if(gt) gt.onclick=()=>{ if((Save.data.tokens||0)<20){ this.toast("Need 20 YSC tokens."); return; } Save.data.tokens-=20; Save.data.gems+=10; Save.save(); this.renderStore(); this.renderClub(); this.toast("+10 gems."); };
    const tc=$("#exTokenCoin");
    if(tc) tc.onclick=()=>{ if((Save.data.tokens||0)<5){ this.toast("Need 5 YSC tokens."); return; } Save.data.tokens-=5; Save.data.coins+=250000; Save.save(); this.renderStore(); this.renderClub(); this.toast("+250,000 Sx."); };
  },
  bindDiff(){
    const wrap=$("#diffBtns");
    if(wrap)["easy","medium","hard"].forEach(d=>{ const b=document.createElement("button"); b.className="mini"; b.textContent=d; b.onclick=()=>{ this.diff=d; Settings.set("difficulty",d); const sd=$("#setDiff"); if(sd) sd.value=d; this.renderDiff(); }; wrap.appendChild(b); });
    this.renderDiff();
  },
  renderDiff(){ $$("#diffBtns .mini").forEach(b=>b.classList.toggle("on", b.textContent===this.diff)); },
  bindSettings(){
    const S=Settings.data;
    $("#setMusic").checked=S.music; $("#setCommentator").checked=S.commentator; $("#setSfx").checked=S.sfx; $("#setVibe").checked=S.vibe;
    $("#setHud").value=S.hud; $("#setDiff").value=S.difficulty; this.diff=S.difficulty; this.renderDiff();
    $("#setMusic").onchange=e=>Settings.set("music",e.target.checked);
    $("#setCommentator").onchange=e=>Settings.set("commentator",e.target.checked);
    $("#setSfx").onchange=e=>Settings.set("sfx",e.target.checked);
    $("#setVibe").onchange=e=>Settings.set("vibe",e.target.checked);
    $("#setHud").onchange=e=>{ Settings.set("hud",e.target.value); this.applySettings(); };
    $("#setDiff").onchange=e=>{ Settings.set("difficulty",e.target.value); this.diff=e.target.value; this.renderDiff(); };
  },
  applySettings(){
    const h=$("#hud"); if(h){ h.classList.remove("leftmode","large");
      if(Settings.data.hud==="left") h.classList.add("leftmode");
      if(Settings.data.hud==="large") h.classList.add("large"); }
    if(window.GameAudio) GameAudio.setOptions(Settings.data);
  },
  bindCodes(){
    $("#codesBar").onclick=()=>{ $("#codeInput").value=""; $("#codeModal").classList.add("show"); $("#codeInput").focus(); };
    $("#codeCancel").onclick=()=>$("#codeModal").classList.remove("show");
    $("#codeRedeem").onclick=()=>this.redeemCode();
    $("#codeInput").addEventListener("keydown",e=>{ if(e.key==="Enter") this.redeemCode(); });
  },
  redeemCode(){
    const res=Codes.redeem($("#codeInput").value);
    if(!res.ok){ this.toast(res.reason); return; }
    const d=res.def;
    if(d.type==="money"){ Save.data.coins+=d.amount; }
    else if(d.type==="picks"){ Save.data.picks+=d.amount; }
    else if(d.type==="player"){ Save.data.squad.push(d.player); }
    else if(d.type==="tokens"){ Save.data.tokens=(Save.data.tokens||0)+d.amount; }
    Save.save(); this.renderClub(); this.renderStore();
    $("#codeModal").classList.remove("show");
    this.toast("Redeemed: "+res.label);
  },
  renderMarket(){
    const list=$("#marketList"); if(!list) return;
    const q=($("#marketSearch").value||"").toLowerCase();
    list.innerHTML="";
    const pool=MARKET_POOL.filter(p=>!q || p.n.toLowerCase().includes(q)).sort((a,b)=>b.r-a.r).slice(0,60);
    pool.forEach(p=>{
      const price=priceOf(p.r);
      const card=document.createElement("div"); card.className="card";
      card.innerHTML='<div class="p"><b>'+p.n+'</b><small>'+p.p+' · '+p.c+' · '+p.nat+'</small></div>'+
        '<div style="display:flex;gap:10px;align-items:center"><span class="rating">'+p.r+'</span><button class="buy">'+price.toLocaleString()+'</button></div>';
      card.querySelector(".buy").onclick=()=>this.buyPlayer(p,price);
      list.appendChild(card);
    });
    $("#marketSearch").oninput=()=>this.renderMarket();
    this.coins();
  },
  buyPlayer(p,price){
    if(Save.data.picks>0){ Save.data.picks--; }
    else if(Save.data.coins>=price){ Save.data.coins-=price; }
    else { this.toast("Not enough Sx."); return; }
    Save.data.squad.push(p); Save.save(); this.renderClub(); this.renderMarket();
    this.toast("Signed "+p.n);
  },

  /* ---------------- STORE ---------------- */
  renderStore(){
    const body=$("#storeBody"); if(!body) return;
    body.innerHTML="";

    // packs
    const packSec=document.createElement("div"); packSec.className="shopsec";
    packSec.innerHTML='<h3>PLAYER PACKS · open an animation, get a player</h3>';
    const grid=document.createElement("div"); grid.className="shopgrid";
    PACK_TIERS.forEach(t=>{
      const owned=(Save.data.picks||0);
      const it=document.createElement("div"); it.className="shopitem";
      it.innerHTML='<span class="pill '+t.band+'">'+t.band.toUpperCase()+'</span>'+
        '<div class="ti">'+t.name+'</div><div class="de">'+t.desc+'</div>'+
        '<div class="price">'+(t.cur==="gems"?"💎":"🟢")+' '+t.cost+' '+(t.cur==="gems"?"gems":"YSC tokens")+'</div>';
      const b=document.createElement("button"); b.className="buy"; b.textContent="Open pack";
      b.onclick=()=>this.openPack(t.id);
      it.appendChild(b); grid.appendChild(it);
    });
    packSec.appendChild(grid); body.appendChild(packSec);

    // tokens (real money stub)
    const tokSec=document.createElement("div"); tokSec.className="shopsec";
    tokSec.innerHTML='<h3>YSC TOKENS · the premium currency</h3>';
    const tg=document.createElement("div"); tg.className="shopgrid";
    [{t:"Token Pouch",n:"600 YSC tokens",v:"$4.99"},{t:"Token Bag",n:"3,000 YSC tokens",v:"$19.99"},{t:"Token Chest",n:"8,000 YSC tokens",v:"$49.99"}].forEach(p=>{
      const it=document.createElement("div"); it.className="shopitem";
      it.innerHTML='<span class="pill soon">COMING SOON</span><div class="ti">'+p.t+'</div><div class="de">'+p.n+'</div><div class="price">'+p.v+' (real money)</div>';
      const b=document.createElement("button"); b.className="buy"; b.textContent="Not live yet"; b.disabled=true;
      it.appendChild(b); tg.appendChild(it);
    });
    tokSec.appendChild(tg);
    tokSec.insertAdjacentHTML("beforeend",'<p class="stub">Tokens can only be bought with real money, and that checkout is not switched on yet. For now the only way to get tokens is the code bar.</p>');
    body.appendChild(tokSec);

    // custom team
    const cusSec=document.createElement("div"); cusSec.className="shopsec";
    cusSec.innerHTML='<h3>TEAM</h3>';
    const cg=document.createElement("div"); cg.className="shopgrid";
    const owned=!!Save.data.teamCustom;
    const ci=document.createElement("div"); ci.className="shopitem";
    ci.innerHTML='<div class="ti">Custom Team Kit</div><div class="de">Unlock kit colours (shirt / shorts / number) in TEAM BADGE.</div>'+
      '<div class="price">25 YSC tokens</div>';
    const cb=document.createElement("button"); cb.className="buy"; cb.textContent=owned?"Owned":"Unlock";
    if(owned) cb.disabled=true;
    cb.onclick=()=>{
      if(owned) return;
      if((Save.data.tokens||0)<25){ this.toast("Need 25 YSC tokens."); return; }
      Save.data.tokens-=25; Save.data.teamCustom=true; Save.save(); this.renderStore(); this.renderClub(); this.toast("Custom kit unlocked.");
    };
    ci.appendChild(cb); cg.appendChild(ci);
    cusSec.appendChild(cg); body.appendChild(cusSec);
  },
  openPack(id){
    const tier=PACK_TIERS.find(t=>t.id===id); if(!tier) return;
    if(tier.cur==="gems" && (Save.data.gems||0)<tier.cost){ this.toast("Not enough gems."); return; }
    if(tier.cur==="tokens" && (Save.data.tokens||0)<tier.cost){ this.toast("Not enough YSC tokens."); return; }
    if(tier.cur==="gems") Save.data.gems-=tier.cost; else Save.data.tokens-=tier.cost;
    Save.save(); this.coins(); this.renderStore();

    const player=drawPackPlayer(tier, MARKET_POOL.concat(this.myPool()));
    this._packPlayer=player; this._packTier=tier;

    const pack=$("#packPack"), card=$("#packCard"), actions=$("#packActions"), hint=$("#packHint");
    pack.style.display=""; pack.className="pak"; pack.dataset.open="";
    card.className="pcardwrap"; actions.className="row packactions"; hint.textContent="Tap the pack to open";
    $("#pakLabel").textContent=tier.band.toUpperCase();
    const pc=card.querySelector(".pcard"); pc.className="pcard "+tier.band;
    $("#pcRating").textContent=player.r||70;
    $("#pcPos").textContent=player.p||"";
    $("#pcName").textContent=player.n||"";
    $("#pcClub").textContent=(player.c||"Free agent")+(player.icon?" · ICON":"");
    $("#packModal").classList.add("show");
  },
  bindPack(){
    const pack=$("#packPack"), card=$("#packCard"), actions=$("#packActions"), hint=$("#packHint");
    if(!pack) return;
    pack.onclick=()=>{
      if(pack.dataset.open) return; pack.dataset.open="1";
      pack.className="pak shake"; hint.textContent="Opening...";
      setTimeout(()=>{
        pack.className="pak burst"; hint.textContent="";
        setTimeout(()=>{
          pack.style.display="none"; card.className="pcardwrap show"; actions.className="row packactions show";
        }, 460);
      }, 700);
    };
    const close=()=>$("#packModal").classList.remove("show");
    $("#packSign").onclick=()=>{
      const p=this._packPlayer; if(p){ Save.data.squad.push(p); Save.save(); this.renderClub(); this.toast("Signed "+p.n); }
      close();
    };
    $("#packModal").addEventListener("click",e=>{ if(e.target===$("#packModal")) close(); });
  },

  /* ---------------- MANAGERS + CAMPAIGN ---------------- */
  renderManagers(){
    const list=$("#managerList"); if(!list) return; list.innerHTML="";
    const owned=Save.data.managers||[];
    MANAGERS.forEach(m=>{
      const have=owned.includes(m.id);
      const card=document.createElement("div"); card.className="card mgr";
      card.innerHTML='<div class="p"><b>'+m.n+' <span class="pill">'+m.tier+'</span></b><small>'+m.desc+'</small></div>';
      const b=document.createElement("button"); b.className=have?"buy":"buy"; b.textContent=have?"Hired":(m.cost+" 💎");
      if(have) b.disabled=true;
      b.onclick=()=>{
        if((Save.data.gems||0)<m.cost){ this.toast("Not enough gems."); return; }
        Save.data.gems-=m.cost; Save.data.managers=owned.concat([m.id]); Save.save();
        this.renderManagers(); this.renderClub(); this.toast("Hired "+m.n);
      };
      card.appendChild(b); list.appendChild(card);
    });
  },
  renderCampaign(){
    const list=$("#campaignList"); if(!list) return; list.innerHTML="";
    const stages=["Opening Fixture","Derby Day","Cup Round 1","The Big Two","Title Decider"];
    stages.forEach((s,i)=>{
      const card=document.createElement("div"); card.className="card";
      const locked=i>Save.data.campaign;
      card.innerHTML='<div class="p"><b>'+(i+1)+'. '+s+'</b><small>Reward: '+((i+1)*25000).toLocaleString()+' Sx</small></div>';
      const b=document.createElement("button"); b.className="buy"; b.textContent=locked?"Locked":"Play";
      if(locked) b.disabled=true;
      b.onclick=()=>{ this.pendingReward={coins:250000, stage:i}; this.show("match"); this.startMatch(); };
      card.appendChild(b); list.appendChild(card);
    });
  },
  renderDaily(){
    const list=$("#dailyList"); if(!list) return; list.innerHTML="";
    const today=new Date().toISOString().slice(0,10);
    if(Save.data.dailyDate!==today){ Save.data.dailyDate=today; Save.data.dailyDone=[]; Save.save(); }
    const tasks=[
      {id:"play1",t:"Play 1 match",rw:20000},
      {id:"win1",t:"Win 1 match",rw:40000},
      {id:"score3",t:"Score 3 goals",rw:30000},
    ];
    tasks.forEach(task=>{
      const done=Save.data.dailyDone.includes(task.id);
      const card=document.createElement("div"); card.className="card";
      card.innerHTML='<div class="p"><b>'+task.t+'</b><small>+'+task.rw.toLocaleString()+' Sx</small></div>';
      const b=document.createElement("button"); b.className="buy"; b.textContent=done?"Claimed":"Claim";
      if(done) b.disabled=true;
      b.onclick=()=>{ Save.data.dailyDone.push(task.id); Save.data.coins+=task.rw; Save.save(); this.renderDaily(); this.coins(); this.toast("+"+task.rw.toLocaleString()+" Sx"); };
      card.appendChild(b); list.appendChild(card);
    });
  },
  showCommentary(key){
    const txt=(window.GameAudio&&GameAudio.LINES[key])||"";
    if(!txt) return;
    const el=$("#commentary"); el.textContent=txt;
    el.classList.remove("show"); void el.offsetWidth; el.classList.add("show");
  },
  bindMatchUI(){
    const stick=$("#stick"), nub=$("#nub"); let active=false;
    const rect=()=>stick.getBoundingClientRect();
    const move=(e)=>{ const p=e.touches?e.touches[0]:e; const r=rect(); const dx=p.clientX-(r.left+r.width/2), dy=p.clientY-(r.top+r.height/2);
      const max=r.width/2-20, len=Math.hypot(dx,dy)||1, k=Math.min(1,max/len);
      nub.style.transform='translate('+(dx*k)+'px,'+(dy*k)+'px)';
      if(this.match){ this.match.controls.mx=dx/len*Math.min(1,len/max); this.match.controls.my=dy/len*Math.min(1,len/max); } };
    const end=()=>{ active=false; nub.style.transform=""; if(this.match){this.match.controls.mx=0;this.match.controls.my=0;} };
    stick.addEventListener("touchstart",e=>{active=true;move(e);e.preventDefault();});
    stick.addEventListener("touchmove",e=>{if(active)move(e);e.preventDefault();});
    stick.addEventListener("touchend",end);
    stick.addEventListener("mousedown",e=>{active=true;move(e);});
    window.addEventListener("mousemove",e=>{if(active)move(e);});
    window.addEventListener("mouseup",end);
    const down=(el,key)=>{ el.addEventListener("touchstart",e=>{ if(this.match)this.match.controls[key]=true; e.preventDefault(); });
      el.addEventListener("touchend",()=>{ if(this.match)this.match.controls[key]=false; });
      el.addEventListener("mousedown",()=>{ if(this.match)this.match.controls[key]=true; });
      el.addEventListener("mouseup",()=>{ if(this.match)this.match.controls[key]=false; }); };
    down($("#btnShoot"),"shoot"); down($("#btnPass"),"pass"); down($("#btnTackle"),"tackle");
    $("#btnQuit").onclick=()=>{ if(this.match)this.match.stop(); this.match=null; this.show("menu"); };
  },
  startMatch(){
    this.show("match");
    const stage=$("#pitch");
    if(this.match){ try{ this.match.stop(); }catch(e){} this.match=null; }
    const homePool = (Save.data.squad && Save.data.squad.length>=11) ? Save.data.squad : ICONS.concat(Save.data.squad || []);
    const homeXI = buildEleven(homePool);
    const opp = TEAMS[1+Math.floor(Math.random()*(TEAMS.length-1))];
    const awayXI = clubEleven(opp.name);
    const k = Save.data.kit || {};
    const yscKit = { shirt:k.shirt||"#c8102e", shorts:k.shorts||"#0b0b10", num:k.num||"#ffcf3f" };
    const m=new Match(stage,{
      difficulty:this.diff, homeName:Save.data.clubName||"YSC", awayName:opp.name,
      homeKit:yscKit, awayKit:opp.k1,
      homeSquad:homeXI, awaySquad:awayXI,
      onGoal:(t)=>{ this.updateScore(); if(Settings.data.vibe&&navigator.vibrate) navigator.vibrate(60); },
      onSay:(key)=>{ this.showCommentary(key); },
      onEnd:(sc)=>{ this.endMatch(sc,opp); }
    });
    this.match=m; m.resize(); m.start(); this.updateScore();
    const tick=setInterval(()=>{ if(!this.match){clearInterval(tick);return;} const cl=$("#clock"); if(cl) cl.textContent=this.clockStr(); },250);
  },
  clockStr(){ const m=this.match; if(!m) return "00:00"; const g=Math.floor(m.clock); return String(Math.floor(g/60)).padStart(2,"0")+":"+String(g%60).padStart(2,"0"); },
  updateScore(){ const m=this.match; if(!m) return; $("#score").textContent=m.score.h+" - "+m.score.a; $("#homeName").textContent=m.homeName; $("#awayName").textContent=m.awayName; },
  endMatch(sc,opp){
    this.show("result");
    const win = sc.h>sc.a, draw = sc.h===sc.a;
    const reward = win?250000:draw?120000:60000;
    Save.data.coins+=reward;
    Save.data.xp=(Save.data.xp||0)+(win?15:draw?10:6);
    Save.save(); this.coins(); this.renderHome();
    $("#resTitle").textContent = win?"Full Time - You Win":draw?"Full Time - Draw":"Full Time - Lost";
    $("#resScore").textContent = sc.h+" - "+sc.a;
    $("#resRewards").textContent = "Reward: +"+reward.toLocaleString()+" Sx";
    this.match=null;
  }
};
document.addEventListener("DOMContentLoaded",()=>App.init());
