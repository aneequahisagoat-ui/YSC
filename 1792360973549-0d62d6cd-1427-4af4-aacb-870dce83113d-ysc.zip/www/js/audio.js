/* YSC audio: crowd, referee whistle, and a match commentator.
   Crowd + whistle are synthesised with WebAudio, so they need no files and work offline.
   Commentary plays bundled voice clips (window.YSC_VOICE, see audio/voice.js) and, if
   those are missing, falls back to the device's installed speech voice. */
(function(){
const LINES = {
  kickoff: "We're underway!",
  goal1:   "Goal! What a finish!",
  goal2:   "It's in! Get in there!",
  through: "He's through on goal!",
  save1:   "Brilliant save by the keeper!",
  offside: "Offside! The flag is up!",
  foul:    "Free kick! Crunching challenge!",
  penalty: "Penalty! The referee points to the spot!",
  tackle:  "Great tackle, ball won!",
  final:   "That's full time!"
};

const GameAudio = {
  ctx:null, master:null, crowdGain:null, started:false,
  sfxOn:true, commOn:true, musicOn:true,
  clips:{}, lastSpoke:0,

  init(){
    if(this.started) return; this.started = true;
    try{
      const C = window.AudioContext || window.webkitAudioContext;
      if(!C) return;
      this.ctx = new C();
      this.master = this.ctx.createGain(); this.master.gain.value = 0.85;
      this.master.connect(this.ctx.destination);
      this.buildCrowd();
      // music bed: quiet looping pad so "background music" toggle does something
      this.buildMusic();
    }catch(e){ /* no audio device, silent game */ }
    this.resume();
  },
  resume(){ try{ if(this.ctx && this.ctx.state === "suspended") this.ctx.resume(); }catch(e){} },
  setOptions(o){ if(o.sfx!==undefined)this.sfxOn=o.sfx; if(o.commentator!==undefined)this.commOn=o.commentator; if(o.music!==undefined){this.musicOn=o.music; if(this.musicGain) this.musicGain.gain.value = o.music?0.05:0;} },

  buildCrowd(){
    const ctx=this.ctx;
    const len = Math.floor(ctx.sampleRate*2);
    const buf = ctx.createBuffer(1,len,ctx.sampleRate);
    const d = buf.getChannelData(0);
    for(let i=0;i<len;i++) d[i] = (Math.random()*2-1);
    const src = ctx.createBufferSource(); src.buffer=buf; src.loop=true;
    const bp = ctx.createBiquadFilter(); bp.type="bandpass"; bp.frequency.value=650; bp.Q.value=0.6;
    const hp = ctx.createBiquadFilter(); hp.type="highpass"; hp.frequency.value=250;
    const g = ctx.createGain(); g.gain.value=0.0;
    src.connect(bp); bp.connect(hp); hp.connect(g); g.connect(this.master);
    src.start();
    this.crowdGain = g;
    // slow murmur swell so it breathes instead of hissing flat
    const lfo=ctx.createOscillator(); lfo.frequency.value=0.11;
    const lg=ctx.createGain(); lg.gain.value=0.015;
    lfo.connect(lg); lg.connect(g.gain); lfo.start();
    this.crowdAmbient = 0.055;
  },
  buildMusic(){
    const ctx=this.ctx;
    const g=ctx.createGain(); g.gain.value = this.musicOn?0.05:0;
    g.connect(this.master); this.musicGain=g;
    const notes=[196,246.9,293.7]; // G B D pad
    notes.forEach((f,i)=>{
      const o=ctx.createOscillator(); o.type="triangle"; o.frequency.value=f;
      const og=ctx.createGain(); og.gain.value=0.5;
      const trem=ctx.createOscillator(); trem.frequency.value=0.07+i*0.03;
      const tg=ctx.createGain(); tg.gain.value=0.25;
      trem.connect(tg); tg.connect(og.gain); trem.start();
      o.connect(og); og.connect(g); o.start();
    });
  },
  crowd(level){
    if(!this.ctx || !this.sfxOn) return;
    const t=this.ctx.currentTime;
    try{
      this.crowdGain.gain.cancelScheduledValues(t);
      this.crowdGain.gain.setTargetAtTime(level, t, 0.25);
      this.crowdGain.gain.setTargetAtTime(this.crowdAmbient, t+1.6, 1.2);
    }catch(e){}
  },
  whistle(){
    if(!this.ctx || !this.sfxOn) return;
    const ctx=this.ctx, t=ctx.currentTime;
    const o=ctx.createOscillator(); o.type="sine"; o.frequency.value=2150;
    const g=ctx.createGain();
    g.gain.setValueAtTime(0.0001,t);
    g.gain.linearRampToValueAtTime(0.16,t+0.02);
    g.gain.setValueAtTime(0.16,t+0.22);
    g.gain.linearRampToValueAtTime(0.0001,t+0.30);
    const vib=ctx.createOscillator(); vib.frequency.value=32;
    const vg=ctx.createGain(); vg.gain.value=70; vib.connect(vg); vg.connect(o.frequency);
    vib.start(t); vib.stop(t+0.34);
    o.connect(g); g.connect(this.master); o.start(t); o.stop(t+0.32);
  },
  thump(){ // ball-kick / contact click
    if(!this.ctx || !this.sfxOn) return;
    const ctx=this.ctx, t=ctx.currentTime;
    const o=ctx.createOscillator(); o.type="square"; o.frequency.setValueAtTime(180,t); o.frequency.exponentialRampToValueAtTime(60,t+0.08);
    const g=ctx.createGain(); g.gain.setValueAtTime(0.06,t); g.gain.exponentialRampToValueAtTime(0.0001,t+0.10);
    o.connect(g); g.connect(this.master); o.start(t); o.stop(t+0.12);
  },
  say(key){
    if(!this.commOn) { this.notify(key); return; }
    this.notify(key);
    const clip = (window.YSC_VOICE||{})[key];
    if(clip){
      try{
        let a = this.clips[key] || (this.clips[key]=new Audio(clip));
        a.currentTime=0; a.volume=1;
        const p=a.play(); if(p&&p.catch) p.catch(()=>{});
        return;
      }catch(e){}
    }
    // fallback: on-device speech voice
    try{
      if(!window.speechSynthesis || this.sfxOn===false) return;
      const txt = LINES[key]; if(!txt) return;
      const u=new SpeechSynthesisUtterance(txt);
      u.rate=1.15; u.pitch=1.1; u.volume=1;
      window.speechSynthesis.cancel(); window.speechSynthesis.speak(u);
    }catch(e){}
  },
  notify(key){ if(this.onLine) this.onLine(key, LINES[key]||""); }
};
window.GameAudio = GameAudio;
GameAudio.LINES = LINES;
})();
