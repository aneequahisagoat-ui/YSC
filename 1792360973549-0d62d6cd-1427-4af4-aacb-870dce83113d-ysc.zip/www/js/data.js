/* YSC player data.
   Scope: PREMIER LEAGUE players + ICONS (legends). That's it.
   Add rows here any time; the game reads PLAYERS + ICONS at boot. */

const PLAYERS = [
  // --- GOALKEEPERS ---
  {n:"Alisson Becker",r:89,p:"GK",c:"Liverpool",nat:"Brazil"},
  {n:"Ederson",r:87,p:"GK",c:"Man City",nat:"Brazil"},
  {n:"David Raya",r:85,p:"GK",c:"Arsenal",nat:"Spain"},
  {n:"Andre Onana",r:83,p:"GK",c:"Man United",nat:"Cameroon"},
  {n:"Guglielmo Vicario",r:84,p:"GK",c:"Tottenham",nat:"Italy"},
  {n:"Emiliano Martinez",r:86,p:"GK",c:"Aston Villa",nat:"Argentina"},
  {n:"Nick Pope",r:83,p:"GK",c:"Newcastle",nat:"England"},
  // --- DEFENDERS ---
  {n:"Virgil van Dijk",r:89,p:"CB",c:"Liverpool",nat:"Netherlands"},
  {n:"Ruben Dias",r:89,p:"CB",c:"Man City",nat:"Portugal"},
  {n:"William Saliba",r:86,p:"CB",c:"Arsenal",nat:"France"},
  {n:"Gabriel Magalhaes",r:85,p:"CB",c:"Arsenal",nat:"Brazil"},
  {n:"Josko Gvardiol",r:85,p:"LB",c:"Man City",nat:"Croatia"},
  {n:"Trent Alexander-Arnold",r:86,p:"RB",c:"Liverpool",nat:"England"},
  {n:"Andrew Robertson",r:85,p:"LB",c:"Liverpool",nat:"Scotland"},
  {n:"Ben White",r:84,p:"RB",c:"Arsenal",nat:"England"},
  {n:"Lisandro Martinez",r:84,p:"CB",c:"Man United",nat:"Argentina"},
  {n:"Cristian Romero",r:85,p:"CB",c:"Tottenham",nat:"Argentina"},
  {n:"Micky van de Ven",r:83,p:"CB",c:"Tottenham",nat:"Netherlands"},
  {n:"Kieran Trippier",r:82,p:"RB",c:"Newcastle",nat:"England"},
  {n:"Sven Botman",r:83,p:"CB",c:"Newcastle",nat:"Netherlands"},
  {n:"Levi Colwill",r:82,p:"CB",c:"Chelsea",nat:"England"},
  {n:"Reece James",r:84,p:"RB",c:"Chelsea",nat:"England"},
  // --- MIDFIELDERS ---
  {n:"Rodri",r:91,p:"DM",c:"Man City",nat:"Spain"},
  {n:"Kevin De Bruyne",r:91,p:"CAM",c:"Man City",nat:"Belgium"},
  {n:"Bernardo Silva",r:88,p:"CM",c:"Man City",nat:"Portugal"},
  {n:"Phil Foden",r:88,p:"CAM",c:"Man City",nat:"England"},
  {n:"Declan Rice",r:88,p:"DM",c:"Arsenal",nat:"England"},
  {n:"Martin Odegaard",r:88,p:"CAM",c:"Arsenal",nat:"Norway"},
  {n:"Bruno Fernandes",r:87,p:"CAM",c:"Man United",nat:"Portugal"},
  {n:"Kobbie Mainoo",r:81,p:"CM",c:"Man United",nat:"England"},
  {n:"Enzo Fernandez",r:84,p:"CM",c:"Chelsea",nat:"Argentina"},
  {n:"Moises Caicedo",r:85,p:"DM",c:"Chelsea",nat:"Ecuador"},
  {n:"Cole Palmer",r:86,p:"CAM",c:"Chelsea",nat:"England"},
  {n:"Dominik Szoboszlai",r:84,p:"CM",c:"Liverpool",nat:"Hungary"},
  {n:"Ryan Gravenberch",r:83,p:"CM",c:"Liverpool",nat:"Netherlands"},
  {n:"Alexis Mac Allister",r:86,p:"CM",c:"Liverpool",nat:"Argentina"},
  {n:"James Maddison",r:84,p:"CAM",c:"Tottenham",nat:"England"},
  {n:"Bruno Guimaraes",r:85,p:"CM",c:"Newcastle",nat:"Brazil"},
  {n:"Douglas Luiz",r:83,p:"CM",c:"Aston Villa",nat:"Brazil"},
  {n:"John McGinn",r:82,p:"CM",c:"Aston Villa",nat:"Scotland"},
  // --- FORWARDS ---
  {n:"Erling Haaland",r:91,p:"ST",c:"Man City",nat:"Norway"},
  {n:"Mohamed Salah",r:89,p:"RW",c:"Liverpool",nat:"Egypt"},
  {n:"Son Heung-min",r:86,p:"LW",c:"Tottenham",nat:"South Korea"},
  {n:"Bukayo Saka",r:88,p:"RW",c:"Arsenal",nat:"England"},
  {n:"Gabriel Martinelli",r:84,p:"LW",c:"Arsenal",nat:"Brazil"},
  {n:"Kai Havertz",r:84,p:"ST",c:"Arsenal",nat:"Germany"},
  {n:"Marcus Rashford",r:84,p:"LW",c:"Man United",nat:"England"},
  {n:"Rasmus Hojlund",r:82,p:"ST",c:"Man United",nat:"Denmark"},
  {n:"Alexander Isak",r:86,p:"ST",c:"Newcastle",nat:"Sweden"},
  {n:"Anthony Gordon",r:83,p:"LW",c:"Newcastle",nat:"England"},
  {n:"Ollie Watkins",r:85,p:"ST",c:"Aston Villa",nat:"England"},
  {n:"Nicolas Jackson",r:82,p:"ST",c:"Chelsea",nat:"Senegal"},
  {n:"Luis Diaz",r:85,p:"LW",c:"Liverpool",nat:"Colombia"},
  {n:"Diogo Jota",r:84,p:"ST",c:"Liverpool",nat:"Portugal"},
  {n:"Darwin Nunez",r:83,p:"ST",c:"Liverpool",nat:"Uruguay"},
];

/* ICONS - the legends. Over asked for icons like Messi, Ronaldo, Pele. */
const ICONS = [
  {n:"Pele",r:98,p:"CAM",c:"Icons",nat:"Brazil",icon:true},
  {n:"Diego Maradona",r:98,p:"CAM",c:"Icons",nat:"Argentina",icon:true},
  {n:"Lionel Messi (Prime)",r:97,p:"RW",c:"Icons",nat:"Argentina",icon:true},
  {n:"Cristiano Ronaldo (Prime)",r:97,p:"ST",c:"Icons",nat:"Portugal",icon:true},
  {n:"Ronaldo Nazario",r:96,p:"ST",c:"Icons",nat:"Brazil",icon:true},
  {n:"Zinedine Zidane",r:96,p:"CAM",c:"Icons",nat:"France",icon:true},
  {n:"Ronaldinho",r:95,p:"LW",c:"Icons",nat:"Brazil",icon:true},
  {n:"Johan Cruyff",r:95,p:"ST",c:"Icons",nat:"Netherlands",icon:true},
  {n:"Franz Beckenbauer",r:95,p:"CB",c:"Icons",nat:"Germany",icon:true},
  {n:"Ferenc Puskas",r:94,p:"ST",c:"Icons",nat:"Hungary",icon:true},
  {n:"Alfredo Di Stefano",r:94,p:"ST",c:"Icons",nat:"Spain",icon:true},
  {n:"Paolo Maldini",r:94,p:"CB",c:"Icons",nat:"Italy",icon:true},
  {n:"Franco Baresi",r:94,p:"CB",c:"Icons",nat:"Italy",icon:true},
  {n:"Roberto Baggio",r:93,p:"CAM",c:"Icons",nat:"Italy",icon:true},
  {n:"Romario",r:93,p:"ST",c:"Icons",nat:"Brazil",icon:true},
  {n:"Thierry Henry",r:93,p:"ST",c:"Icons",nat:"France",icon:true},
  {n:"Ruud Gullit",r:93,p:"CAM",c:"Icons",nat:"Netherlands",icon:true},
  {n:"Kaka",r:92,p:"CAM",c:"Icons",nat:"Brazil",icon:true},
  {n:"Steven Gerrard",r:92,p:"CM",c:"Icons",nat:"England",icon:true},
  {n:"Frank Lampard",r:92,p:"CM",c:"Icons",nat:"England",icon:true},
  {n:"Eric Cantona",r:92,p:"ST",c:"Icons",nat:"France",icon:true},
  {n:"Alan Shearer",r:91,p:"ST",c:"Icons",nat:"England",icon:true},
  {n:"Ryan Giggs",r:91,p:"LW",c:"Icons",nat:"Wales",icon:true},
  {n:"Paul Scholes",r:91,p:"CM",c:"Icons",nat:"England",icon:true},
  {n:"Didier Drogba",r:90,p:"ST",c:"Icons",nat:"Ivory Coast",icon:true},
  {n:"Samuel Eto'o",r:91,p:"ST",c:"Icons",nat:"Cameroon",icon:true},
  {n:"Lev Yashin",r:92,p:"GK",c:"Icons",nat:"Russia",icon:true},
  {n:"Gianluigi Buffon",r:91,p:"GK",c:"Icons",nat:"Italy",icon:true},
  {n:"Iker Casillas",r:91,p:"GK",c:"Icons",nat:"Spain",icon:true},
  {n:"Xavi Hernandez",r:92,p:"CM",c:"Icons",nat:"Spain",icon:true},
  {n:"Andres Iniesta",r:92,p:"CM",c:"Icons",nat:"Spain",icon:true},
  {n:"Carles Puyol",r:90,p:"CB",c:"Icons",nat:"Spain",icon:true},
  {n:"Raul Gonzalez",r:91,p:"ST",c:"Icons",nat:"Spain",icon:true},
  {n:"Alessandro Nesta",r:91,p:"CB",c:"Icons",nat:"Italy",icon:true},
  {n:"Fabio Cannavaro",r:90,p:"CB",c:"Icons",nat:"Italy",icon:true},
];

/* Premier League clubs, 2 kits each (home + away). Kit selection comes later. */
const TEAMS = [
  {name:"Man City",short:"MCI",k1:{shirt:"#6cabdd",shorts:"#ffffff",num:"#1c2c5b"},k2:{shirt:"#1c2c5b",shorts:"#1c2c5b",num:"#6cabdd"}},
  {name:"Arsenal",short:"ARS",k1:{shirt:"#ef0107",shorts:"#ffffff",num:"#ffffff"},k2:{shirt:"#1b1b1b",shorts:"#1b1b1b",num:"#ef0107"}},
  {name:"Liverpool",short:"LIV",k1:{shirt:"#c8102e",shorts:"#c8102e",num:"#ffffff"},k2:{shirt:"#111318",shorts:"#111318",num:"#c8102e"}},
  {name:"Man United",short:"MUN",k1:{shirt:"#da291c",shorts:"#ffffff",num:"#111318"},k2:{shirt:"#ffffff",shorts:"#111318",num:"#da291c"}},
  {name:"Chelsea",short:"CHE",k1:{shirt:"#034694",shorts:"#034694",num:"#ffffff"},k2:{shirt:"#ffffff",shorts:"#034694",num:"#034694"}},
  {name:"Tottenham",short:"TOT",k1:{shirt:"#ffffff",shorts:"#0f204b",num:"#0f204b"},k2:{shirt:"#0f204b",shorts:"#0f204b",num:"#ffffff"}},
  {name:"Newcastle",short:"NEW",k1:{shirt:"#241f20",shorts:"#ffffff",num:"#ffffff"},k2:{shirt:"#ffffff",shorts:"#241f20",num:"#241f20"}},
  {name:"Aston Villa",short:"AVL",k1:{shirt:"#95bfe5",shorts:"#ffffff",num:"#670e36"},k2:{shirt:"#670e36",shorts:"#670e36",num:"#95bfe5"}},
];

/* name pool for filler players (keeps the market deep without breaking scope) */
const FIRST = ["Jack","Harry","Callum","Ollie","Reece","Tyrone","Marcus","Josh","Kyle","Dean","Connor","Alfie","Mason","Leo","Aaron","Kai","Noah","Dylan","Finley","Charlie"];
const LAST = ["Bennett","Hughes","Clarke","Ward","Doyle","Fletcher","Barnes","Rowe","Mercer","Priest","Hall","Neville","Sutton","Pearce","Dawson","Bramley","Coles","Vance","Okafor","Silva"];
const POS = ["GK","RB","CB","CB","LB","DM","CM","CAM","RW","LW","ST"];
const CLUBS = ["Free Agents","Reserves","Youth Academy","Loaned Out"];

function generatePlayers(count){
  const out=[];
  for(let i=0;i<count;i++){
    const r=Math.max(55,Math.min(83,Math.round(55+Math.random()*28)));
    out.push({ n: FIRST[i%FIRST.length]+" "+LAST[(i*7+3)%LAST.length], r, p:POS[i%POS.length], c:CLUBS[i%CLUBS.length], nat:"England", gen:true });
  }
  return out;
}

/* market: Premier League + icons + a generated filler pool */
const MARKET_POOL = PLAYERS.concat(ICONS).concat(generatePlayers(160));

function priceOf(rating){ return Math.round(400*Math.pow(rating/60,3.2)); }

/* ============================================================
   LOOKS - how each player reads on the pitch in 3D.
   Real likenesses (actual faces) aren't possible; instead every player gets a
   distinct silhouette: skin tone, hair colour + style, hair volume and build.
   Icons and big names get hand-tuned looks; everyone else is derived from
   their name + nationality so it stays stable between sessions.
   ============================================================ */

/* skin tone by nationality (approx, deliberately coarse) */
const NAT_SKIN = {
  Brazil:0x9c6a3f, Argentina:0xe0b088, Portugal:0xd39b6d, England:0xf0ccc0,
  Spain:0xe6bb92, France:0xdcaa86, Netherlands:0xf0ccc0, Belgium:0xe8c39e,
  Germany:0xf0ccc0, Italy:0xe3b58c, Croatia:0xe8c39e, Scotland:0xf2d3c0,
  Norway:0xf2d3c0, Denmark:0xf0ccc0, Sweden:0xf0ccc0, Senegal:0x6b4226,
  Colombia:0xb07a4e, Uruguay:0xe0b088, Egypt:0xc98d55, "South Korea":0xf0d3ae,
  Hungary:0xe8c39e, Cameroon:0x6b4226, Ghana:0x6b4226, Nigeria:0x6b4226,
  Wales:0xf0ccc0, "Ivory Coast":0x6b4226, Russia:0xf0ccc0, Ecuador:0xa9713f
};
const HAIR_C = [0x1a1310,0x241a12,0x120f0d,0x3a2a1a,0x5b3d22,0x8a6b3a,0xc9a86a,0x0d0d0d];

/* hand-tuned looks for icons + names Over called out. s=skin, h=hair, hv=hair volume, st=style, b=build */
const PLAYER_LOOKS = {
  "Pele":                       {s:0x6b4226,h:0x120f0d,hv:0.6,st:"curly",b:1.0},
  "Diego Maradona":             {s:0xb07a4e,h:0x1a1310,hv:1.4,st:"curly",b:0.9},
  "Lionel Messi (Prime)":       {s:0xe0b088,h:0x3a2a1a,hv:1.1,st:"short",b:0.9},
  "Cristiano Ronaldo (Prime)":  {s:0xd39b6d,h:0x120f0d,hv:0.7,st:"neat",b:1.04},
  "Ronaldo Nazario":            {s:0xa9713f,h:0x1a1310,hv:0.5,st:"buzz",b:1.0},
  "Zinedine Zidane":            {s:0xdcaa86,h:0x2a1c12,hv:0.0,st:"bald",b:1.02},
  "Ronaldinho":                 {s:0x9c6a3f,h:0x120f0d,hv:1.6,st:"long",b:1.0},
  "Johan Cruyff":               {s:0xf0ccc0,h:0x3a2a1a,hv:1.2,st:"long",b:1.0},
  "David Beckham":              {s:0xf0ccc0,h:0xc9a86a,hv:1.0,st:"neat",b:1.0},
  "Thierry Henry":              {s:0x6b4226,h:0x120f0d,hv:1.3,st:"short",b:1.0},
  "Kaka":                       {s:0xe0b088,h:0x3a2a1a,hv:1.0,st:"neat",b:1.0},
  "Erling Haaland":             {s:0xf2d3c0,h:0xc9a86a,hv:1.3,st:"long",b:1.05},
  "Mohamed Salah":              {s:0xb07a4e,h:0x1a1310,hv:1.7,st:"curly",b:1.0},
  "Kevin De Bruyne":            {s:0xf0ccc0,h:0xc9a86a,hv:0.9,st:"neat",b:1.0},
  "Virgil van Dijk":            {s:0x6b4226,h:0x0d0d0d,hv:0.4,st:"buzz",b:1.06}
};

function hashName(str){
  let h=2166136261;
  for(let i=0;i<str.length;i++){ h^=str.charCodeAt(i); h=Math.imul(h,16777619); }
  return (h>>>0);
}
function lookFor(p){
  if(PLAYER_LOOKS[p.n]) return Object.assign({}, PLAYER_LOOKS[p.n]);
  const h=hashName(p.n);
  const gk = p.p==="GK";
  const big = p.p==="CB"||p.p==="ST"||gk;
  return {
    s: NAT_SKIN[p.nat] !== undefined ? NAT_SKIN[p.nat] : 0xd9a173,
    h: HAIR_C[h % HAIR_C.length],
    hv: 0.4 + ((h>>3) % 12)/10,
    st: ["short","neat","buzz","curly","long","bald"][(h>>5)%6],
    b: (big?1.04:0.97) + ((h>>7)%5)/100
  };
}

/* --------- lineup builder: turn a player pool into an XI for the 3D match --------- */
const SLOTS = ["GK","RB","CB","CB","LB","CM","CM","CM","RW","ST","LW"];
const SLOT_OK = {
  GK:["GK"], RB:["RB","CB"], CB:["CB","RB","LB","DM"], LB:["LB","CB"],
  CM:["CM","DM","CAM"], RW:["RW","LW","ST"], ST:["ST","LW","RW"], LW:["LW","RW","ST"]
};
function buildEleven(pool){
  if(!pool || !pool.length) return [];
  const used=new Set(), out=[];
  const sorted = pool.slice().sort((a,b)=>b.r-a.r);
  SLOTS.forEach(slot=>{
    let pick = sorted.find(p=>!used.has(p) && SLOT_OK[slot].includes(p.p));
    if(!pick) pick = sorted.find(p=>!used.has(p));
    if(pick){ used.add(pick); out.push(pick); }
  });
  return out;
}
/* a club's best XI from the real data */
function clubEleven(club){
  return buildEleven(PLAYERS.filter(p=>p.c===club));
}

/* ============================================================
   STORE - player packs, managers, customisation.
   ============================================================ */

/* Pack tiers. Packs are opened with an animation and reveal one player
   from the pool that fits the tier's rating band. */
const PACK_TIERS = [
  { id:"standard",  name:"STANDARD PACK", band:"elite",     cost:5,  cur:"gems",   minR:78, maxR:86, desc:"Elite squad filler. 78-86 rated." },
  { id:"premium",   name:"PREMIUM PACK",  band:"legendary", cost:12, cur:"gems",   minR:85, maxR:92, desc:"Legendary. 85-92 rated." },
  { id:"ultimate",  name:"ULTIMATE PACK", band:"icon",      cost:6,  cur:"tokens", minR:92, maxR:99, desc:"Icon pull. 92-99 rated, YSC tokens only." }
];

/* Managers. Bought with gems from the CAMPAIGN screen; each adds a flat
   boost to your XI's effective overall. */
const MANAGERS = [
  { id:"m1", n:"Coach Bellamy",  tier:"Bronze", bonus:1, cost:15, desc:"+1 team OVR" },
  { id:"m2", n:"Coach Ferraro",  tier:"Silver", bonus:2, cost:30, desc:"+2 team OVR" },
  { id:"m3", n:"Coach Nakamura", tier:"Gold",   bonus:3, cost:60, desc:"+3 team OVR" },
  { id:"m4", n:"Coach Oliveira", tier:"Elite",  bonus:5, cost:120, desc:"+5 team OVR" }
];

/* draw a player for a pack tier from the market pool (or any pool fallback) */
function drawPackPlayer(tier, pool){
  const src = (pool && pool.length ? pool : MARKET_POOL)
    .filter(p => (p.r||70) >= tier.minR && (p.r||70) <= tier.maxR);
  const list = src.length ? src : MARKET_POOL.slice().sort((a,b)=>b.r-a.r).slice(0,25);
  const p = list[Math.floor(Math.random()*list.length)];
  return Object.assign({}, p, { packBand: tier.band });
}
