/* YSC settings: music / commentator / sfx / vibration / HUD / difficulty */
const DEFAULT_SETTINGS = { music:true, commentator:true, sfx:true, vibe:true, hud:"right", difficulty:"medium" };
const Settings = {
  data: Object.assign({}, DEFAULT_SETTINGS),
  load(){
    try { Object.assign(this.data, JSON.parse(localStorage.getItem("ysc_settings")||"{}")); } catch(e){}
    return this.data;
  },
  save(){
    localStorage.setItem("ysc_settings", JSON.stringify(this.data));
  },
  set(k,v){ this.data[k]=v; this.save(); }
};
