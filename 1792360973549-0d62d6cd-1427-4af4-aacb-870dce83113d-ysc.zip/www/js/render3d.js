/* YSC 3D match renderer (Three.js).
   Keeps the exact same match simulation from game.js (metres on a 105x68 pitch)
   and just draws it in 3D: pitched grass, real goals, and low-poly players with
   distinct silhouettes (skin tone, hair, build) so each one reads as its own guy.
   Everything is generated at runtime, so the game stays 100% offline. */
(function(){
if(!window.THREE) return;

const PITCH_W = 105, PITCH_H = 68;
const GOAL_W = 7.32, GOAL_H = 2.44;
const HAIR_STYLES = ["short","neat","buzz","curly","long","bald"];

/* ---------- shared geometry / material caches (cheap on phones) ---------- */
const geoCache = {};
function capsule(r, len){
  const k="c"+r+"_"+len;
  return geoCache[k] || (geoCache[k]=new THREE.CapsuleGeometry(r, len, 4, 8));
}
const matCache = {};
function mat(color, opts){
  opts = opts || {};
  const k=color+"_"+JSON.stringify(opts);
  if(matCache[k]) return matCache[k];
  const o = { color: color };
  if(opts.emissive) o.emissive = opts.emissive;
  if(opts.rough !== undefined) o.roughness = opts.rough;
  return matCache[k] = new THREE.MeshLambertMaterial(o);
}

/* ---------- grass + line markings drawn to a canvas, mapped on the pitch ---------- */
function pitchTexture(){
  const S = 10; // px per metre
  const cv = document.createElement("canvas");
  cv.width = PITCH_W*S; cv.height = PITCH_H*S;
  const x = cv.getContext("2d");
  // mowing stripes
  const bands = 14, bw = cv.width/bands;
  for(let i=0;i<bands;i++){
    x.fillStyle = i%2 ? "#12632c" : "#0d5225";
    x.fillRect(i*bw,0,bw+1,cv.height);
  }
  // darker surround
  x.strokeStyle="rgba(255,255,255,0.85)"; x.lineWidth=2; x.strokeRect(4,4,cv.width-8,cv.height-8);
  x.lineWidth=2;
  // halfway + centre circle + spot
  x.beginPath(); x.moveTo(cv.width/2,0); x.lineTo(cv.width/2,cv.height); x.stroke();
  x.beginPath(); x.arc(cv.width/2,cv.height/2,9.15*S,0,7); x.stroke();
  x.beginPath(); x.arc(cv.width/2,cv.height/2,3,0,7); x.fillStyle="rgba(255,255,255,.85)"; x.fill();
  // boxes both ends
  [0, cv.width].forEach((ex,idx)=>{
    const dir = idx===0?1:-1;
    // penalty box 16.5 deep, 40.32 wide
    x.strokeRect(Math.min(ex, ex+dir*16.5*S), cv.height/2-20.16*S, Math.abs(16.5*S), 40.32*S);
    // goal area 5.5 deep, 18.32 wide
    x.strokeRect(Math.min(ex, ex+dir*5.5*S), cv.height/2-9.16*S, Math.abs(5.5*S), 18.32*S);
    // penalty spot
    x.beginPath(); x.arc(ex+dir*11*S, cv.height/2, 3, 0, 7); x.fill();
    // D arc
    x.beginPath(); x.arc(ex+dir*11*S, cv.height/2, 9.15*S, idx===0?-Math.PI/2.6:Math.PI-Math.PI/2.6, idx===0?Math.PI/2.6:Math.PI+Math.PI/2.6, idx===0?false:false); x.stroke();
  });
  // corner arcs
  [[0,0],[cv.width,0],[0,cv.height],[cv.width,cv.height]].forEach(([cx,cy],i)=>{
    x.beginPath(); x.arc(cx,cy,1*S,0,7); x.stroke();
  });
  const t = new THREE.CanvasTexture(cv);
  if("colorSpace" in t && THREE.SRGBColorSpace) t.colorSpace = THREE.SRGBColorSpace;
  else if(THREE.sRGBEncoding) t.encoding = THREE.sRGBEncoding;
  t.anisotropy = 4;
  return t;
}

/* ---------- one low-poly footballer ---------- */
function buildPlayer(p, kit){
  const look = (typeof lookFor==="function") ? lookFor(p) : {s:0xd9a173,h:0x1a1310,hv:0.8,st:"short",b:1};
  const g = new THREE.Group();
  const shirt = kit.shirt, shorts = kit.shorts, num = kit.num;

  // torso
  const torso = new THREE.Mesh(capsule(0.20,0.42), mat(shirt));
  torso.position.y = 1.22; g.add(torso);
  // number stripe on the back (simple)
  const shortsMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.215,0.20,0.30,10), mat(shorts));
  shortsMesh.position.y = 0.86; g.add(shortsMesh);

  // legs (pivot at hip so they can swing)
  function leg(side){
    const grp = new THREE.Group();
    grp.position.set(side*0.11, 0.80, 0);
    const thigh = new THREE.Mesh(capsule(0.095,0.34), mat(look.s));
    thigh.position.y = -0.30; grp.add(thigh);
    // sock
    const sock = new THREE.Mesh(capsule(0.085,0.20), mat(shirt));
    sock.position.y = -0.62; grp.add(sock);
    // boot
    const boot = new THREE.Mesh(new THREE.BoxGeometry(0.14,0.08,0.24), mat(0x111111));
    boot.position.set(0,-0.78,0.05); grp.add(boot);
    g.add(grp); return grp;
  }
  const legL = leg(-1), legR = leg(1);

  // arms (short sleeve = shirt colour, then skin)
  function arm(side){
    const grp = new THREE.Group();
    grp.position.set(side*0.26, 1.40, 0);
    const sleeve = new THREE.Mesh(capsule(0.065,0.16), mat(shirt));
    sleeve.position.y = -0.14; grp.add(sleeve);
    const fore = new THREE.Mesh(capsule(0.055,0.20), mat(look.s));
    fore.position.y = -0.40; grp.add(fore);
    g.add(grp); return grp;
  }
  const armL = arm(-1), armR = arm(1);

  // head + hair
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.135,14,12), mat(look.s));
  head.position.y = 1.62; g.add(head);
  if(look.st!=="bald" && look.hv>0.05){
    const hg = new THREE.SphereGeometry(0.142,14,12);
    let hs = new THREE.Mesh(hg, mat(look.h));
    hs.scale.set(1,0.72+(look.hv*0.25),1);
    hs.position.y = 1.66 + look.hv*0.02;
    g.add(hs);
    if(look.st==="curly" || look.st==="long"){
      const back = new THREE.Mesh(new THREE.SphereGeometry(0.145,12,10), mat(look.h));
      back.scale.set(1,0.9,1.15); back.position.set(0,1.60,-0.03); g.add(back);
    }
    if(look.st==="long"){
      const tail = new THREE.Mesh(new THREE.BoxGeometry(0.22,0.30*look.hv,0.12), mat(look.h));
      tail.position.set(0,1.44,-0.10); g.add(tail);
    }
  }
  g.scale.setScalar(look.b);
  g.userData = { legL, legR, armL, armR, phase: Math.random()*Math.PI*2, look };
  return g;
}

/* ---------- floating name label ---------- */
function makeLabel(text){
  const cv = document.createElement("canvas"); cv.width=256; cv.height=64;
  const x = cv.getContext("2d");
  x.fillStyle="rgba(0,0,0,0.55)"; x.fillRect(0,0,256,64);
  x.fillStyle="#fff"; x.font="bold 34px system-ui, sans-serif";
  x.textAlign="center"; x.textBaseline="middle"; x.fillText(text.slice(0,14),128,34);
  const t = new THREE.CanvasTexture(cv);
  if("colorSpace" in t && THREE.SRGBColorSpace) t.colorSpace = THREE.SRGBColorSpace;
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map:t, depthTest:false, transparent:true }));
  sp.scale.set(2.4,0.6,1);
  return sp;
}

/* ---------- the renderer ---------- */
class Pitch3D {
  constructor(container, match){
    this.el = container;
    this.match = match;
    this.canvas = document.createElement("canvas");
    this.canvas.className = "pitch3d";
    this.el.appendChild(this.canvas);

    this.renderer = new THREE.WebGLRenderer({ canvas:this.canvas, antialias:true, powerPreference:"high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1, 2));
    if("outputColorSpace" in this.renderer && THREE.SRGBColorSpace) this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    else if(THREE.sRGBEncoding) this.renderer.outputEncoding = THREE.sRGBEncoding;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a1410);
    this.scene.fog = new THREE.Fog(0x0a1410, 90, 190);

    // lights
    const hemi = new THREE.HemisphereLight(0xffffff, 0x24402c, 1.0); this.scene.add(hemi);
    const sun = new THREE.DirectionalLight(0xffffff, 1.15); sun.position.set(40,70,30); this.scene.add(sun);
    const fill = new THREE.DirectionalLight(0xbcd0ff, 0.35); fill.position.set(-40,40,-30); this.scene.add(fill);

    // pitch
    const pitch = new THREE.Mesh(new THREE.PlaneGeometry(PITCH_W,PITCH_H), new THREE.MeshLambertMaterial({ map:pitchTexture() }));
    pitch.rotation.x = -Math.PI/2; this.scene.add(pitch);

    // goals
    [ -PITCH_W/2, PITCH_W/2 ].forEach(x=>this.buildGoal(x));

    // ball
    const ballTex = ballTexture();
    this.ball = new THREE.Mesh(new THREE.SphereGeometry(0.16,18,16), new THREE.MeshPhongMaterial({ color:0xffffff, map:ballTex, shininess:20 }));
    this.scene.add(this.ball);

    // players
    this.figures = [];
    match.home.concat(match.away).forEach(p=>{
      const fig = buildPlayer(p, p.team===0?match.homeKit:match.awayKit);
      const label = (p.name && p.name.length) ? makeLabel(lastName(p.name)) : null;
      if(label){ label.position.y = 2.05; fig.add(label); }
      this.scene.add(fig);
      this.figures.push({ p, fig });
    });

    // camera
    this.camera = new THREE.PerspectiveCamera(45, 16/9, 0.5, 400);
    this.camPos = new THREE.Vector3(0,16,52);
    this.camLook = new THREE.Vector3(0,0,0);
    this.resize();
  }

  buildGoal(x){
    const m = mat(0xf4f7fa);
    const side = x<0?-1:1;
    const post1 = new THREE.Mesh(new THREE.CylinderGeometry(0.07,0.07,GOAL_H,8), m);
    post1.position.set(x, GOAL_H/2, -GOAL_W/2); this.scene.add(post1);
    const post2 = post1.clone(); post2.position.z = GOAL_W/2; this.scene.add(post2);
    const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.07,0.07,GOAL_W,8), m);
    bar.rotation.x = Math.PI/2; bar.position.set(x, GOAL_H, 0); this.scene.add(bar);
    // net
    const netMat = new THREE.MeshBasicMaterial({ color:0xffffff, wireframe:true, transparent:true, opacity:0.28 });
    const back = new THREE.Mesh(new THREE.PlaneGeometry(2.0,GOAL_W), netMat);
    back.rotation.y = Math.PI/2; back.position.set(x+side*1.0, GOAL_H/2, 0); this.scene.add(back);
    const top = new THREE.Mesh(new THREE.PlaneGeometry(2.0,GOAL_W), netMat);
    top.rotation.x = -Math.PI/2; top.position.set(x+side*1.0, GOAL_H, 0); this.scene.add(top);
  }

  resize(){
    const r = this.el.getBoundingClientRect();
    const w = Math.max(1, r.width), h = Math.max(1, r.height);
    this.renderer.setSize(w,h,false);
    this.camera.aspect = w/h; this.camera.updateProjectionMatrix();
  }

  render(m){
    const b = m.ball;
    // figures
    this.figures.forEach(({p,fig})=>{
      const a = p.anim || (p.anim = {kick:0,dive:0,tackle:0,cele:0,stun:0});
      const X = p.x - PITCH_W/2, Z = p.y - PITCH_H/2;
      const sp = Math.hypot(p.vx, p.vy);
      const ud = fig.userData;
      let baseY = 0, rotX = 0, rotZ = 0;
      if(sp > 0.3 && a.dive<=0 && a.cele<=0) fig.rotation.y = Math.atan2(p.vx, p.vy);
      ud.phase += (0.6 + sp*0.9) * 0.18;
      const sw = Math.min(1, sp/6);
      const s = Math.sin(ud.phase);

      // --- run cycle (base pose) ---
      ud.legL.rotation.x = s*sw*1.0; ud.legR.rotation.x = -s*sw*1.0;
      ud.armL.rotation.x = -s*sw*0.9; ud.armR.rotation.x = s*sw*0.9;
      ud.armL.rotation.z = 0.10; ud.armR.rotation.z = -0.10;

      // --- keeper idle: low ready stance, gloves out ---
      if(p.role==="GK" && a.dive<=0){
        baseY = -0.10;
        ud.armL.rotation.x = -0.5; ud.armR.rotation.x = -0.5;
        ud.armL.rotation.z = 0.55; ud.armR.rotation.z = -0.55;
        ud.legL.rotation.x = 0.25; ud.legR.rotation.x = -0.25;
      }

      // --- striking the ball: big leg swing, plant, torso lean ---
      if(a.kick>0){
        const k = Math.min(1, a.kick/0.40);
        const swing = Math.sin((1-k)*Math.PI);
        ud.legR.rotation.x = -1.55*swing;
        ud.legL.rotation.x = 0.30*swing;
        ud.armL.rotation.x = -0.9*swing; ud.armR.rotation.x = 0.6*swing;
        rotX = 0.14*swing;
      }
      // --- slide tackle: low lunge forward ---
      if(a.tackle>0){
        const k = Math.min(1, a.tackle/0.45);
        const lunge = Math.sin((1-k)*Math.PI);
        rotX = -0.95*lunge; baseY = -0.28*lunge;
        ud.legL.rotation.x = -1.20*lunge; ud.legR.rotation.x = 0.70*lunge;
        ud.armL.rotation.x = 0.9*lunge; ud.armR.rotation.x = 0.5*lunge;
      }
      // --- keeper dive: full-body flop toward the ball ---
      if(a.dive>0){
        const prog = Math.min(1, (1 - a.dive/0.9)*1.6);
        rotZ = -(p.diveDir||1)*1.30*prog;
        baseY = -0.55*prog;
        ud.armL.rotation.x = -0.2; ud.armR.rotation.x = -0.2;
        ud.armL.rotation.z = 1.45; ud.armR.rotation.z = -1.45;
        ud.legL.rotation.x = 0.5; ud.legR.rotation.x = 0.5;
      }
      // --- celebration: arms up, bounce ---
      if(a.cele>0){
        const pump = Math.abs(Math.sin(ud.phase*1.5));
        baseY = 0.16*pump;
        ud.armL.rotation.x = -2.5; ud.armR.rotation.x = -2.5;
        ud.armL.rotation.z = 0.45; ud.armR.rotation.z = -0.45;
        ud.legL.rotation.x = 0.25; ud.legR.rotation.x = -0.25;
      }
      if(a.stun>0){ rotX = 0.55; baseY = -0.30; }

      fig.position.set(X, baseY, Z);
      fig.rotation.x = rotX; fig.rotation.z = rotZ;

      // label only near the ball to keep it clean
      const nearBall = Math.hypot(X-(b.x-PITCH_W/2), Z-(b.y-PITCH_H/2)) < 16;
      if(fig.children.length && fig.children[fig.children.length-1].isSprite)
        fig.children[fig.children.length-1].visible = nearBall;
    });
    // ball
    this.ball.position.set(b.x-PITCH_W/2, 0.16, b.y-PITCH_H/2);
    this.ball.rotation.z -= b.vx*0.02; this.ball.rotation.x += b.vy*0.02;

    // broadcast side camera, follows the ball
    const bx = b.x-PITCH_W/2, bz = b.y-PITCH_H/2;
    const camX = Math.max(-PITCH_W/2-6, Math.min(PITCH_W/2+6, bx*0.75));
    const camZ = PITCH_H/2 + 22;
    const camY = 15;
    this.camPos.lerp(new THREE.Vector3(camX, camY, camZ), 0.08);
    this.camLook.lerp(new THREE.Vector3(bx, 0.5, bz*0.7), 0.12);
    this.camera.position.copy(this.camPos);
    this.camera.lookAt(this.camLook);

    this.renderer.render(this.scene, this.camera);
  }
}

function lastName(n){ const a=n.split(" "); return a[a.length-1]; }

function ballTexture(){
  const cv=document.createElement("canvas"); cv.width=cv.height=128;
  const x=cv.getContext("2d");
  x.fillStyle="#ffffff"; x.fillRect(0,0,128,128);
  x.fillStyle="#111"; 
  for(let i=0;i<6;i++){ x.beginPath(); x.arc(20+ (i%3)*44, 22+Math.floor(i/3)*60, 12, 0, 7); x.fill(); }
  const t=new THREE.CanvasTexture(cv);
  return t;
}

window.Pitch3D = Pitch3D;
})();
