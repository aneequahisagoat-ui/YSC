# YSC CODES

This is the **codes file**. Every promo/gift code lives here so you can add your own
without touching the game logic.

Codes are redeemed from the **codes bar at the top of the screen** (tap `YSC CODE ▸`).
Each code is **single-use per install**.

## How to add a code
Open `www/js/codes.js` and add a line to `DEFAULT_CODES`:

```js
"YOURCODE": { type:"money",  amount:500000, label:"+500,000 Sx" },
"PLAYERX":  { type:"player", player:{ n:"Player Name", r:95, p:"ST", c:"Your Soccer Club", nat:"Country" }, label:"Player Name" },
"PICKS":    { type:"picks",  amount:5, label:"5 free market picks" },
"YSC600":   { type:"tokens", amount:600, label:"+600 YSC Tokens" },
```

Effect types:
- `money`  -> adds `amount` Sx to the wallet
- `player` -> adds the given player to your squad (free)
- `picks`  -> gives `amount` free market picks (buy without paying)
- `tokens` -> adds `amount` YSC Tokens (the green premium currency)

## Pre-installed codes
| Code | Effect |
|------|--------|
| `MONEY`   | +100,000 Sx |
| `RONALDO` | Prime Cristiano Ronaldo (rating 99) |
| `GIFT`    | 3 free market picks |
| `YSC600`  | +600 YSC Tokens |

Tokens are the premium currency: spent on Ultimate packs and the Custom Team Kit, and
in the STORE. Buying tokens with real money is **not switched on yet**, so codes are
currently the only token source.

> Note: `MONEY` was specced as "100Sx" - I read that as 100k Sx (100 is useless next
> to player prices of 100k+). Change `amount` in codes.js if you meant something else.
